from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,"index.html")

def Home(request):
    return render(request,"home.html")

def aboutt(request):
    return render(request,'aboutus.html')

def term(request):
    return render(request,'term.html')

def information(request):
    return render(request, 'just_been_diagnosed.html')

def type1(request):
    return render(request,'type1.html')

def type2(request):
    return render(request,'type2.html')

def blood_monitoring(request):
    return render(request,'blood_glucose_monitoring.html')

def familyandcare(request):
    return render(request,'family_and_care.html')

def kidandteen(request):
    return render(request,'kid_and_teen.html')

